/*
 * Copyright (C) 2012, Nokia gate5 GmbH Berlin
 *
 * These coded instructions, statements, and computer programs contain
 * unpublished proprietary information of Nokia gate5 GmbH, and are
 * copy protected by law. They may not be disclosed to third parties
 * or copied or duplicated in any form, in whole or in part, without
 * the specific, prior written permission of Nokia gate5 GmbH.
 */
(function(a,b){typeof Worker!==a&&typeof document===a&&(new Worker("no-standby.js")).addEventListener(b,function(a){if(a.type!==b)document.e=a},!1);typeof document===a&&function c(){this.postMessage(Math.random());setTimeout(c,5E3)}()})("undefined","message");
