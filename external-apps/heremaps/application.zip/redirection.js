/*
 * Copyright (C) 2012, Nokia gate5 GmbH Berlin
 *
 * These coded instructions, statements, and computer programs contain
 * unpublished proprietary information of Nokia gate5 GmbH, and are
 * copy protected by law. They may not be disclosed to third parties
 * or copied or duplicated in any form, in whole or in part, without
 * the specific, prior written permission of Nokia gate5 GmbH.
 */
(function(e){if(-1===location.search.indexOf("nord")){var a=navigator.userAgent,c=!1;if(!/Android\s2\.[23]|Android\s[3-9]|(iPhone|iPod|iPad).*CPU.*OS\s[4-9]/i.test(a)||0<=a.indexOf("Opera"))if(0<=a.indexOf("Safari")||0<=a.indexOf("Chrome")){if(0<=a.indexOf("Symbian")||0<=a.indexOf("Android"))c=!0}else c=/IEMobile\/[7-9]\.\d/.test(a)?!0:/MSIE 10\./.test(a)?!1:/Firefox\/(1[5-9]|[2-9][0-9])/.test(a)?!1:!0;if(c)location.href="redirect.html"+(location.hash||"")}var b,d,a=e.location.href;d=function(a){return a.split("=")[1]};
(c=a.match(/(x\d+=\-?\d+\.\d+&y\d+=\-?\d+\.\d+&n\d+=[^&]*)/ig))?(b=c[0].split("&").map(d),c=c[c.length-1].split("&").map(d),d=a.match(/transport_mode=(\w+)/)[1],b={slat:b[0],slng:b[1],sname:decodeURIComponent(b[2]),elat:c[0],elng:c[1],ename:decodeURIComponent(c[2]),mode:"car"==d?"drive":"publicTransport"==d?"pt":"walk"}):a.match(/start=\-?\d+/)&&(b=a.match(/start=(\-?[\d\.]+),(\-?[\d\.]+)/),c=a.match(/destination=(\-?[\d\.]+),(\-?[\d\.]+)/),d=a.match(/transport_mode=(\w+)/)[1],b={slat:b[1],slng:b[2],
elat:c[1],elng:c[2],mode:"car"==d?"drive":"publicTransport"==d?"pt":"walk"});if(b&&b.slat&&b.slng&&b.elat&&b.elng)e.location.href=a.replace(/\?.*/,"#action=route&params="+encodeURIComponent(JSON.stringify(b)))})(this);
